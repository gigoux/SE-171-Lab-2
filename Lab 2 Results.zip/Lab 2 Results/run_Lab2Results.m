close all;
clear;
clc;

results_ideal = importdata("Lab2_t7_ideal.dat");
results_impact = importdata("Lab2_t7_impact.dat");

%Ideal Crack Data
data_ideal = results_ideal.data;
data_ideal(:, 2) = data_ideal(:, 2) - data_ideal(1, 2);
max_loc_ideal = find(data_ideal(:, 3) == max(data_ideal(:, 3)));
max_disp_ideal = data_ideal(max_loc_ideal, 2);
max_load_ideal = data_ideal(max_loc_ideal, 3);


%Impacted Damage Data
data_impact = results_impact.data;
data_impact(:, 2) = data_impact(:, 2) - data_impact(1, 2);
max_loc_impact = find(data_impact(:, 3) == max(data_impact(:, 3)));
max_disp_impact = data_impact(max_loc_impact, 2);
max_load_impact = data_impact(max_loc_impact, 3);

figure(1);
hold on;
grid on;
plot(data_ideal(:, 2), data_ideal(:, 3));
plot(max_disp_ideal, max_load_ideal, "ro", "MarkerSize", 10, "MarkerFaceColor", "r");
xlabel('Specimen Displacement [mm]');
ylabel('Applied Axial (Tensile) Loading [kN]');
title('Stepped Lap Joint for an Ideal Crack');
xlim([0 data_ideal(end, 2)+0.5]);
ylim([0 max(data_ideal(:, 3))+1]);
set(gca, "FontSize", 20);
legend("Loading Curve", strcat("Max Loading: ", num2str(max_load_ideal), " kN"), "Location", "northwest");

figure(2);
hold on;
grid on;
plot(data_impact(:, 2) - data_impact(1, 2), data_impact(:, 3));
plot(max_disp_impact, max_load_impact, "ro", "MarkerSize", 10, "MarkerFaceColor", "r");
xlabel('Specimen Displacement [mm]');
ylabel('Applied Axial (Tensile) Loading [kN]');
title('Stepped Lap Joint for Impacted Damage');
xlim([0 data_impact(end, 2)+0.5]);
ylim([0 max(data_impact(:, 3))+1]);
set(gca, "FontSize", 20);
legend("Loading Curve", strcat("Max Loading: ", num2str(max_load_impact), " kN"), "Location", "northwest");