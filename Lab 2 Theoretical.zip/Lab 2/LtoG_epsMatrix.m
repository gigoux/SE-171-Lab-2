function LtGMatrix = LtoG_epsMatrix(LMatrix, thetavec)

LtGMatrix = cell(length(thetavec), 1);

for i = 1:length(thetavec)
    T_eps = [cosd(thetavec(i))^2, sind(thetavec(i))^2, cosd(thetavec(i))*sind(thetavec(i)); ...
    sind(thetavec(i))^2, cosd(thetavec(i))^2, -cosd(thetavec(i))*sind(thetavec(i)); ...
    -2*cosd(thetavec(i))*sind(thetavec(i)), 2*cosd(thetavec(i))*sind(thetavec(i)), cosd(thetavec(i))^2 - sind(thetavec(i))^2];

    LtGMatrix{i} = T_eps\LMatrix;
end

end
