function volk_OG_output = volkerson_OG(E_o, E_i, G_a, t_o, t_i, t_a, c, N_x)

%%Define Bondline Length
x_stepcount = 101; %can be changed for more precise measurements
x = linspace(-c, c, x_stepcount);
pos = x + c;


%%Volkerson Model Constants
lambda_sq = (G_a / t_a) * ( 1/(E_o*t_o) + 1/(E_i*t_i) );
lambda = sqrt(lambda_sq);

C_0 = (G_a * N_x) / (E_i * t_a * t_i);
B_0 = N_x / (2*sinh(lambda*c));
A_0 = ( N_x - (2*C_0/lambda_sq) ) / (2*cosh(lambda*c));


%%Average Shear Stress
tau_ave = N_x / (2*c);


%%Calculate Adhesive Shear Stress Profile
tau = lambda * ( (N_x/2 - C_0/lambda_sq)*(sinh(lambda*x)/cosh(lambda*c)) + ...
    (N_x/2)*(cosh(lambda*x)/sinh(lambda*c)) );
tau_max = max(tau);
x_max = x( find(tau == tau_max) );


%%Calculate Outer Adherend Axial Stress Profile
N_o = A_0*cosh(lambda*x) + B_0*sinh(lambda*x) + C_0/lambda_sq;


%%Create a Cell with Outputs
volk_OG_output = cell(5, 1);
volk_OG_output{1} = pos; %Position Vector for each Step
volk_OG_output{2} = tau; %Adhesive Shear Stress Profile
volk_OG_output{3} = N_o; %Outer Adherend Axial Stress Profile
volk_OG_output{4} = tau_ave; %Average Shear Stress
volk_OG_output{5} = [x_max, tau_max]; %Maximum Shear Stress

end