function effModuli = EffectiveModuli(A, h)

A_inv = inv(A);

%Effective Moduli
E_x = 1 / (h * A_inv(1, 1)); %Young's modulus in x-direction
E_y = 1 / (h * A_inv(2, 2)); %Young's modulus in y-direction
G_xy = 1 / (h * A_inv(3, 3)); %Shear modulus

%Effective Poisson's Ratio
nu_xy = -A_inv(1, 2) / A_inv(1, 1); %contraction in y-direction due to uniaxial loading in x-direction
nu_yx = -A_inv(1, 2) / A_inv(2, 2); %contraction in x-direction due to uniaxial loading in y-direction

%effective Coefficient of Mututal Influence
eta_xyx = A_inv(1, 3) / A_inv(3, 3); %normal strain in x-direction caused by shear in xy plane
eta_xyy = A_inv(2, 3) / A_inv(3, 3); %normal strain in y-direction caused by shear in xy plane


effModuli = zeros(7, 1);
effModuli(1) = E_x; %Young's modulus in x-direction
effModuli(2) = E_y; %Young's modulus in y-direction
effModuli(3) = G_xy; %Shear modulus
effModuli(4) = nu_xy; %contraction in y-direction due to uniaxial loading in x-direction
effModuli(5) = nu_yx; %contraction in x-direction due to uniaxial loading in y-direction
effModuli(6) = eta_xyx; %normal strain in x-direction caused by shear in xy plane
effModuli(7) = eta_xyy; %normal strain in y-direction caused by shear in xy plane

end