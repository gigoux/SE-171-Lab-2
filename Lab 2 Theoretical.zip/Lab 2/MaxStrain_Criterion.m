function maxStrain = MaxStrain_Criterion(startCond, strProp, zvec, thetavec, ABD_Inv, elsProp)

%Define Strain Strength Properties from Load Strength Properties
Xt_eps = strProp(1) / elsProp(1); %X_eps
Y_teps = strProp(2) / elsProp(2); %Y_eps
Xc_eps = strProp(3) / elsProp(1); %(X_eps)'
Y_ceps = strProp(4) / elsProp(2); %(Y_eps)'
S_eps = strProp(5) / elsProp(3); %S_eps

%Set up inverse ABD matrices
alpha = ABD_Inv{1};
beta = ABD_Inv{2};
delta = ABD_Inv{3};

%Predefine loop conditions
strcond_a = 1; %testing longitudinal failure
strcond_b = 1; %testing transverse failure
strcond_c = 1; %testing in-plane shear failure

%Establish Initial Estimates
N_fail = startCond{1}; %initial guess for failure force loading
M_fail = startCond{2}; %initial guess for failure moment loading


while strcond_a == 1 && strcond_b == 1 && strcond_c == 1
    
    %Define in-plane strains (eps0) and plate curvatures (kap)
    eps0 = alpha*N_fail + beta*M_fail;
    kap = transpose(beta)*N_fail + delta*M_fail;
    
    %Global Strains
    eps_G = cell(length(zvec), 1);
    %Local Strains
    eps_L = cell(length(zvec), 1);

    for i = 1:length(zvec)

        eps_G{i} = eps0 + zvec(i)*kap;
        eps_L{i} = GtoL_epsMatrix(eps_G{i}, thetavec(i));
        eps_L{i} = cell2mat(eps_L{i});

        %Longitudinal Failure (Tension or Compression)
        if abs(eps_L{i}(1)) >= Xt_eps || abs(eps_L{i}(1)) >= Xc_eps
            strcond_a = 0;
            break
        end

        %Transverse Failure (Tension or Compression)
        if abs(eps_L{i}(2)) >= Y_teps || abs(eps_L{i}(2)) >= Y_ceps
            strcond_b = 0;
            break
        end

        %In-Plane Shear Failure
        if abs(eps_L{i}(3)) >= S_eps
            strcond_c = 0;
            break
        end

    end
    
    if strcond_a == 1 && strcond_b == 1 && strcond_c == 1
        N_fail = N_fail + startCond{3};
        M_fail = M_fail + startCond{4};
    end

end


maxStrain = cell(3, 1);
maxStrain{1} = N_fail; %failure force loadings
maxStrain{2} = M_fail; %failure moment loadings
maxStrain{3} = [strcond_a; strcond_b; strcond_c]; %cause of failure

end