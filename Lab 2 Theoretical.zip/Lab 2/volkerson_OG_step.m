function volk_step_output = volkerson_OG_step(E_o, E_i, G_a, t_o_vec, t_i_vec, t_a_vec, c_vec, N_x)

m = length(c_vec); %number of steps


%%Define Bondline and Position Matrices for each Step 
x_stepcount = 101; %can be changed for more precise measurements
x_mat = zeros(m, x_stepcount);
spec_length_mat = zeros(m, x_stepcount);
pos_mat = zeros(m, x_stepcount);

for k = 1:m

    x_mat(k, :) = linspace(-c_vec(k), c_vec(k), x_stepcount);
    spec_length_mat(k, :) = x_mat(k, :) + c_vec(k);

    if k == 1
        pos_mat(k, :) = spec_length_mat(k, :);
    else
        pos_mat(k, :) = spec_length_mat(k, :) + pos_mat(k-1, x_stepcount);
    end

end


%%Volkerson Model Constants
A_0_vec = zeros(m, 1);
B_0_vec = zeros(m, 1);
C_0_vec = zeros(m, 1);
lambda_sq_vec = zeros(m, 1);
lambda_vec = zeros(m, 1);

alpha_vec = zeros(m, 1);
beta_vec = zeros(m, 1);

for k = 1:m

    C_0_vec(k) = (N_x*G_a) / (t_a_vec(k)*t_i_vec(k)*E_i);
    lambda_sq_vec(k) = (G_a/t_a_vec(k)) * ( 1/(E_o(k)*t_o_vec(k)) + 1/(E_i*t_i_vec(k)) );
    lambda_vec(k) = sqrt(lambda_sq_vec(k));

    alpha_vec(k) = ( lambda_vec(k) * tanh(lambda_vec(k)*c_vec(k)) ) / 2;
    beta_vec(k) = lambda_vec(k) / ( 2*tanh(lambda_vec(k)*c_vec(k)) );

end


%%Calculate Unknown Volerson Model Constants (A_0, B_0)
M_mat = zeros(m-1, m-1);
B_vec = zeros(m-1, 1);

for k = 1:m-1

    %Initializing Matrix M
    M_mat(k, k) = alpha_vec(k) + beta_vec(k) + alpha_vec(k+1) + beta_vec(k+1);

    if k < m-1
        M_mat(k, k+1) = alpha_vec(k+1) - beta_vec(k+1);
        M_mat(k+1, k) = alpha_vec(k+1) - beta_vec(k+1);        
    end
    
    %Initializing Column Vector B
    if k < m-1
        B_vec(k) = (2*alpha_vec(k)*C_0_vec(k))/lambda_sq_vec(k) + ...
            (2*alpha_vec(k+1)*C_0_vec(k+1))/lambda_sq_vec(k+1);
    else
        B_vec(k) = (2*alpha_vec(k)*C_0_vec(k))/lambda_sq_vec(k) + ...
            (2*alpha_vec(k+1)*C_0_vec(k+1))/lambda_sq_vec(k+1) - ...
            (alpha_vec(k+1) - beta_vec(k+1))*N_x;
    end

end

N_o_vec = [0; linsolve(M_mat, B_vec)];

for k = 1:m

    if k < m
        A_0_vec(k) = ( N_o_vec(k) + N_o_vec(k+1) - (2*C_0_vec(k)/lambda_sq_vec(k)) ) / ( 2*cosh(lambda_vec(k)*c_vec(k)) );
        B_0_vec(k) = ( N_o_vec(k+1) - N_o_vec(k) ) / ( 2*sinh(lambda_vec(k)*c_vec(k)) );
    else
        A_0_vec(k) = ( N_o_vec(k) + N_x - (2*C_0_vec(k)/lambda_sq_vec(k)) ) / ( 2*cosh(lambda_vec(k)*c_vec(k)) );
        B_0_vec(k) = ( N_x - N_o_vec(k) ) / ( 2*sinh(lambda_vec(k)*c_vec(k)) );
    end

end


%%Calculate Outer Adherend Axial Stress Profile
N_o_mat = zeros(m, x_stepcount);

for k = 1:m

    N_o_mat(k, :) = A_0_vec(k)*cosh(lambda_vec(k)*x_mat(k, :)) + ...
        B_0_vec(k)*sinh(lambda_vec(k)*x_mat(k, :)) + ...
        C_0_vec(k)/lambda_sq_vec(k);

end


%%Calculate Adhesive Shear Stress Profile
tau_mat = zeros(m, x_stepcount);

for k = 1:m

    if k < m
        tau_mat(k, :) = lambda_vec(k) * ( ( (N_o_vec(k) + N_o_vec(k+1))/2 - C_0_vec(k)/lambda_sq_vec(k) ) * ( sinh(lambda_vec(k)*x_mat(k, :))/cosh(lambda_vec(k)*c_vec(k)) ) ...
            + ( (N_o_vec(k+1) - N_o_vec(k))/2 ) * ( cosh(lambda_vec(k)*x_mat(k, :))/sinh(lambda_vec(k)*c_vec(k)) ) );
    else
        tau_mat(k, :) = lambda_vec(k) * ( ( (N_o_vec(k) + N_x)/2 - C_0_vec(k)/lambda_sq_vec(k) ) * ( sinh(lambda_vec(k)*x_mat(k, :))/cosh(lambda_vec(k)*c_vec(k)) ) ...
            + ( (N_x - N_o_vec(k))/2 ) * ( cosh(lambda_vec(k)*x_mat(k, :))/sinh(lambda_vec(k)*c_vec(k)) ) );
    end

end


%%Create a Cell with Outputs
volk_step_output = cell(4, 1);
volk_step_output{1} = m; %Number of Steps
volk_step_output{2} = pos_mat; %Position Vector for Each Step
volk_step_output{3} = tau_mat; %Adhesive Shear Stress Profile
volk_step_output{4} = N_o_mat; %Outer Adherend Axial Stress Profile

end