function thLoadInfo = ThermalLoading(delT, QbarVec, CTEglobal, thetavec, tvec, zvec, A)

N_T = [0; 0; 0]; %Force Loadings (lb)
M_T = [0; 0; 0]; %Moment Loadings (lb*in)
eCTEglobal = [0; 0; 0]; %Effective CTE (1/F)

for i = 1:length(thetavec)
    N_T = N_T + delT*QbarVec{i}*CTEglobal{i}*tvec(i);
    M_T = M_T + 0.5*delT*QbarVec{i}*CTEglobal{i}*tvec(i)*zvec(i);
    eCTEglobal = eCTEglobal + inv(A)*QbarVec{i}*CTEglobal{i}*tvec(i);
end

thLoadInfo{1} = N_T;
thLoadInfo{2} = M_T;
thLoadInfo{3} = eCTEglobal;

end