function D = D_Matrix(QbarCell,tvec,zvec)

zlen = floor(length(zvec)/2);
tempzvec = [zvec(1:zlen) 0 zvec(zlen+1:length(zvec))];
zbarvec = zeros(1, length(zvec));
for i = 1:length(zvec)
    %Centroidal Distance from Midplane
    zbarvec(i) = ( tempzvec(i) + tempzvec(i+1) ) / 2;
end

D = zeros(3,3);

for i = 1:length(QbarCell)
    tempD = D + QbarCell{i}*(tvec(i)*zbarvec(i)^2+(tvec(i)^3/12));
    D = tempD;
end

end