function maxStress = MaxStress_Criterion(startCond, strProp, zvec, thetavec, ABD_Inv, S)

%Define Load Strength Properties
F1t = strProp(1);
F2t = strProp(2);
F1c = strProp(3);
F2c = strProp(4);
F12su = strProp(5);

%Set up inverse ABD matrices
alpha = ABD_Inv{1};
beta = ABD_Inv{2};
delta = ABD_Inv{3};

%initial guess for failure force loading
strcond_a = 1; %testing longitudinal failure
strcond_b = 1; %testing transverse failure
strcond_c = 1; %testing in-plane shear failure

%Establish Initial Estimates
N_fail = startCond{1}; %initial guess for failure force loading
M_fail = startCond{2}; %initial guess for failure moment loading


while strcond_a == 1 && strcond_b == 1 && strcond_c == 1
    
    %Define in-plane strains (eps0) and plate curvatures (kap)
    eps0 = alpha*N_fail + beta*M_fail;
    kap = transpose(beta)*N_fail + delta*M_fail;
    
    %Global Strains
    eps_G = cell(length(zvec), 1);
    %Local Strains
    eps_L = cell(length(zvec), 1);
    %Local Stresses
    sig_L = cell(length(zvec), 1);    

    for i = 1:length(zvec)

        eps_G{i} = eps0 + zvec(i)*kap;
        eps_L{i} = GtoL_epsMatrix(eps_G{i}, thetavec(i));
        eps_L{i} = cell2mat(eps_L{i});
        sig_L{i} = S\eps_L{i};

        %Longitudinal Failure (Tension or Compression)
        if abs(sig_L{i}(1)) >= F1t || abs(sig_L{i}(1)) >= F1c
            strcond_a = 0;
            break
        end

        %Transverse Failure (Tension or Compression)
        if abs(sig_L{i}(2)) >= F2t || abs(sig_L{i}(2)) >= F2c
            strcond_b = 0;
            break
        end

        %In-Plane Shear Failure
        if abs(sig_L{i}(3)) >= F12su
            strcond_c = 0;
            break
        end

    end

    if strcond_a == 1 && strcond_b == 1 && strcond_c == 1
        N_fail = N_fail + startCond{3};
        M_fail = M_fail + startCond{4};
    end

end


maxStress = cell(3, 1);
maxStress{1} = N_fail; %failure force loadings
maxStress{2} = M_fail; %failure moment loadings
maxStress{3} = [strcond_a; strcond_b; strcond_c]; %cause of failure

end