function B = B_Matrix(QbarCell,tvec,zvec)
    
zlen = floor(length(zvec)/2);
tempzvec = [zvec(1:zlen) 0 zvec(zlen+1:length(zvec))];
zbarvec = zeros(1, length(zvec));
for i = 1:length(zvec)
    %Centroidal Distance from Midplane
    zbarvec(i) = ( tempzvec(i) + tempzvec(i+1) ) / 2;
end

B = zeros(3,3);

for i = 1:length(QbarCell)
    tempB = B + QbarCell{i}*tvec(i)*zbarvec(i);
    B = tempB;
end

end
