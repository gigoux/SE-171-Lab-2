function A = A_Matrix(QbarCell,tvec)
    
A = zeros(3,3);

for i = 1:length(QbarCell)
    tempA = A + QbarCell{i}*tvec(i);
    A = tempA;
end

end
    