close all;
clear;
clc;

%%Defining Material Properties for Applied Joint Material
E1a = 29.7e9; %Youngs Modulus in Fiber Direction [Pa]
E2a = 29.7e9; %Youngs Modulus in Transverse Direction [Pa]
G12a = 5.3e9; %Shear Modulus [Pa]
nu12a = 0.17; %Poissons Ratio in Fiber Direction
nu21a = (E2a*nu12a) / E1a; %Poisonns Ratio in Transverse Direction

th_CF = 0.25e-3; %Ply Thickness [m]


%%Define Ply Orientation for Stepped Lap Joint
theta_step = [0 0 90 45];
theta_step = [theta_step fliplr(theta_step)];
tvec_step = th_CF * ones(1, length(theta_step)); %Ply Thicknesses [m]
zvec_step = zeros(1, length(theta_step)); %Centroid Distances [m]
for i = 1:length(theta_step)/2
    zvec_step(i) = -1 * ( length(theta_step)/2 + 1 - i );
    zvec_step(length(theta_step) + 1 - i) = length(theta_step)/2 + 1 - i;
end
zvec_step = th_CF * zvec_step;


%%Obtain A-Matrix and Effective Moduli for Each Layer of Stepped Lap Joint
ply_count = length(theta_step);
QbarCell_step = cell(ply_count, 1);
A_step = cell(ply_count, 1);
effModuli_step = cell(ply_count, 1);
theta_vec = cell(ply_count, 1);

for ii = 1:ply_count
    theta_vec{ii} = theta_step(1:ii);

    QbarCell_step{ii} = Qbar_Laminate(E1a, E2a, G12a, nu12a, nu21a, theta_vec{ii});

    A_step{ii} = A_Matrix(QbarCell_step{ii}, tvec_step(1:ii));

    effModuli_step{ii} = EffectiveModuli(A_step{ii}, sum(tvec_step(1:ii)));
end


%%Inner Adherend Properties
Ex_FR4 = 25e9; %Young's Modulus in x-direction [Pa]
Ey_FR4 = Ex_FR4; %Young's Modulus in y-direction [Pa]
Gxy_FR4 = 2.6e9; %Shear Modulus [Pa]
nu_xy_FR4 = 0.12; %Major Poisson's Ratio
nu_yx_FR4 = (Ey_FR4*nu_xy_FR4) / Ex_FR4;

th_FR4 = 3.2207e-3; %Inner Adherend Thickness [m]
w_FR4 = 62.5856e-3; %inner Adherend Width [m]


%%Outer Adhered Properties
eff_YM_step = zeros(ply_count, 1); %Effective Young's Modulus for each step
eff_SM_step = zeros(ply_count, 1); %Effective Shear Modulus for each step
for jj = 1:ply_count
    eff_YM_step(jj) = effModuli_step{jj}(1);
    eff_SM_step(jj) = effModuli_step{jj}(3);
end


%%Adhesive Properties
th_adhesive = 0.003 * 0.0254; %Adhesive Thickness [m]
G_adhesive = 0.6e9; %Adhesive Shear Modulus [m]



%%Properties for Stepped Lap
step_count = 4;
th_FR4_vec = th_FR4 * ones(step_count, 1); %FR4 thickness vector
th_CF_vec = ( th_CF * [3 4 5 8] )'; %carbon fiber thickness vector
th_adhesive_vec = th_adhesive * ones(step_count, 1); %adhesive thickness vector
c_step_vec = 0.5*[25.4e-3 * ones(step_count-1, 1); 0.08636]; %bondline length
max_load_step = 1825 * 4.448; %max load [N]
Nx_step = max_load_step/w_FR4; 
eff_YM_step_modified = [eff_YM_step(3); eff_YM_step(4:5); eff_YM_step(8)];
eff_SM_step_modified = [eff_SM_step(3); eff_SM_step(4:5); eff_SM_step(8)];

tau_ult = 38e6;

stepped_info = volkerson_OG_step(eff_YM_step_modified, Ex_FR4, G_adhesive, th_CF_vec, th_FR4_vec, th_adhesive_vec, c_step_vec, Nx_step);


%%Plot Shear Stress Profile vs Average Shear Stress
figure(1)
hold on;
grid on;

%Volkerson OG Step
for k = 1:stepped_info{1}
    plot(stepped_info{2}(k, :), stepped_info{3}(k, :), 'k');
    plot(stepped_info{2}(k, :), tau_ult*ones(length(stepped_info{3}(k, :))), 'r');
end

xlabel('Bondline Across Specimen [m]');
ylabel('Adhesive Shear Stress [Pa]');
title('Adhesive Shear Stress Profile (Applied Loading 8117.6N)');
legend('Stepped Lap Joint', 'Ultimate Shear Stress', 'Location', 'best');

xlim([0 stepped_info{2}(4, end)]);
set(gca, "FontSize", 20);


%%Plot Outer Adherend Axial Stress Profile
figure(2)
hold on;
grid on;

%Volkerson OG Step
for k = 1:stepped_info{1}
    plot(stepped_info{2}(k, :), stepped_info{4}(k, :), 'k');
end

xlabel('Bondline Across Specimen [m]');
ylabel('Adherend Axial Stress [N/m]');
title('Adherend Axial Stress Profile (Applied Loading 8117.6N)');
xlim([0 stepped_info{2}(4, end)]);
ylim([0 Nx_step]);
set(gca, "FontSize", 20);
