function volk_TSD_output = volkerson_TSD(E_o, E_i, G_a, G_o, G_i, t_o, t_i, t_a, c, N_x)

%%Define Bondline Length
x_stepcount = 101; %can be changed for more precise measurements
x = linspace(-c, c, x_stepcount);


%%Volkerson Model Constants
lambda_sq = (G_a / t_a) * ( 1/(E_o*t_o) + 1/(E_i*t_i) );
lambda = sqrt(lambda_sq);

mu_sq = 1 + (G_a*t_o)/(4*t_a*G_o) + (G_a*t_i)/(4*t_a*G_i);
mu = sqrt(mu_sq);

C_0 = (G_a * N_x) / (E_i * t_a * t_i);
B_0 = N_x / (2*sinh((lambda/mu)*c));
A_0 = ( N_x - (2*C_0/lambda_sq) ) / (2*cosh((lambda/mu)*c));


%%Average Shear Stress
tau_ave = N_x / (2*c);


%%Calculate Adhesive Shear Stress Profile
tau = (lambda/mu)*( (N_x/2 - C_0/lambda_sq)*sinh((lambda/mu)*x)/cosh((lambda/mu)*c) + ...
        (N_x/2)*cosh((lambda/mu)*x)/sinh((lambda/mu)*c));
tau_max = max(tau);
x_max = x( find(tau == tau_max, 1, 'first') );


%%Calculate Outer Adherend Axial Stress Profile
N_o = A_0*cosh((lambda/mu)*x) + B_0*sinh((lambda/mu)*x) + C_0/lambda_sq;


%%Create a Cell with Outputs
volk_TSD_output = cell(5, 1);
volk_TSD_output{1} = x; %Position Vector for each Step
volk_TSD_output{2} = tau; %Adhesive Shear Stress Profile
volk_TSD_output{3} = N_o; %Outer Adherend Axial Stress Profile
volk_TSD_output{4} = tau_ave; %Average Shear Stress
volk_TSD_output{5} = [x_max, tau_max]; %Maximum Shear Stress

end